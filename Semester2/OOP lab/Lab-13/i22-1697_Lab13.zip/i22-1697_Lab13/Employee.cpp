/*
 * Employee.cpp
 *
 *  Created on: May 3, 2023
 *      Author: safi
 */

#include "Employee.h"

Employee::Employee(string  s,int i) {
	this->name=s;
	this->empID=i;

}

Employee::~Employee() {
	// TODO Auto-generated destructor stub
}

