/*
 * header.h
 *
 *  Created on: May 12, 2023
 *      Author: safi
 */

#ifndef SRC_HEADER_H_
#define SRC_HEADER_H_
#include <iostream>
#include <fstream>
#include <string>
#include <cstring>//including necessary files.
#include<cstdlib>
#include<ctime>
#include<cmath>
using namespace std;
#endif /* SRC_Header_H_ */
