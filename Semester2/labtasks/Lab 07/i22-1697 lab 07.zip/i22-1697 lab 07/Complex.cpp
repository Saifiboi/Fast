/*
 * Complex.cpp
 *
 *  Created on: Mar 8, 2023
 *      Author: safi
 */

#include "Complex.h"

Complex::Complex(){
	this->real=1;
	this->imaginary=1;
	// TODO Auto-generated constructor stub

}
Complex::Complex(double r,double i) {
	this->real=r;
	this->imaginary=i;
	// TODO Auto-generated constructor stub

}
Complex::Complex(Complex & copy)
	{
		this->imaginary=copy.imaginary;
		this->real=copy.real;
	}

double Complex::getImaginary() const {
	return imaginary;
}

void Complex::setImaginary(double imaginary) {
	this->imaginary = imaginary;
}

double Complex::getReal() const {
	return real;
}

void Complex::setReal(double real) {
	this->real = real;
}
Complex Complex::addComplex(double r)
{
	Complex C2;
	C2.real=this->real+r;
	return C2;

}
Complex Complex::addComplex(Complex &c1)
{
	Complex C2;
	C2.real=this->real+c1.real;
	C2.imaginary=this->imaginary+c1.imaginary;

	return C2;

}
Complex Complex::subComplex(double r)
{
	Complex C2;
	C2.real=this->real-r;
	return C2;

}
Complex Complex::subComplex(Complex &c1)
{
	Complex C2;
	C2.real=this->real-c1.real;
	C2.imaginary=this->imaginary-c1.imaginary;

	return C2;

}
Complex Complex::mulComplex(double r)
{
	Complex C2;
	C2.real=this->real*r;
	C2.imaginary=this->imaginary*r;
	return C2;

}
Complex Complex::mulComplex(Complex &c1)
{
	Complex C2;
	C2.real=this->real*c1.real-this->imaginary*c1.imaginary;
	C2.imaginary=this->real*c1.imaginary+this->imaginary*c1.real;


	return C2;

}
