#ifndef _THROW_EXCEPTION_H
#define _THROW_EXCEPTION_H

struct throw_exception {
  throw_exception &operator=(const throw_exception &rhs);

  static int i_;
};

#endif /* _THROW_EXCEPTION_H */
