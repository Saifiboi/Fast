/* -*- C++ -*- */
#ifndef _VISITOR_CPP_
#define _VISITOR_CPP_

#include "visitors/Visitor.h"

Visitor::~Visitor (void)
{
}

#endif /* _VISITOR_CPP_ */
