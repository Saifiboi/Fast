# ! / b i n / b a s h
mkdir /home/safi/Documents/1
touch /home/safi/Documents/1/1.txt
mkdir /home/safi/Documents/2
touch /home/safi/Documents/2/1.txt
mkdir /home/safi/Documents/3
touch /home/safi/Documents/3/1.txt
