# ! / b i n / b a s h
touch FROM.txt
echo Hello! I am Saif Ur Rehman.My roll no is i221697 >FROM.txt
touch TO.txt
cp FROM.txt TO.txt
rm FROM.txt
mv TO.txt FINAL_FILE.txt
grep Saif FINAL_FILE.txt

