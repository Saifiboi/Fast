# ! / b i n / b a s h
rm  -r /home/safi/Documents/1
rm  -r /home/safi/Documents/2
rm -r  /home/safi/Documents/3
