# ! / b i n / b a s h
date
echo Name : Siaf
echo total Marks  : 300
echo English : 100
echo Urdu : 80
echo Maths : 70
