# ! / b i n / b a s h
touch count.txt
echo 1 > count.txt
echo 2 >> count.txt
echo 3 >> count.txt
echo 4 >> count.txt
echo 5 >> count.txt
echo 6 >> count.txt
echo 7 >> count.txt
echo 8 >> count.txt
echo 9 >> count.txt
sort -r count.txt
