# ! / b i n / b a s h
 read a 
 read b
 read c
 sum=$(($a+$b+$c))
 echo $sum
